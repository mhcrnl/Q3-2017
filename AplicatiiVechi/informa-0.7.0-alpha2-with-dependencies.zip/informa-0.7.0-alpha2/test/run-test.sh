export CLASSPATH=$CLASSPATH:../build/classes:../lib/jdom.jar:../lib/log4j.jar:../lib/lucene.jar
jython import/read.py data/xmlhack-0.91.xml 0.91
