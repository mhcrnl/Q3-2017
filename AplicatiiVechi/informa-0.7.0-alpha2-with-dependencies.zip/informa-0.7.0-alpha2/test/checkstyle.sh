java -cp ../lib/checkstyle-all.jar com.puppycrawl.tools.checkstyle.Main -r ../src/de/nava/informa/impl/basic 
