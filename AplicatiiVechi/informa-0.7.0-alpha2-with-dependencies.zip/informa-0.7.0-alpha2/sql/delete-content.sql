delete from ITEMS;
delete from TEXTINPUTS;
delete from CATEGORIES;
delete from IMAGES;
delete from CHANNELS;
delete from CHANNEL_SUBSCRIPTIONS;
delete from ITEM_METADATA;
delete from CHANNEL_GROUPS;
