#!/usr/bin/perl
# ================================================================
#   Create a new DIRECTORY from input of the user and inside create
#        a new perl FILE insert by user in form of 'my_perl.pl',
#        and a new file README.md, gitpush.sh and executed after
#       permissions.
# ================================================================
use strict;
use warnings;
use Cwd qw(cwd); # LINUX pwd

my $filename;
my $dir = cwd; # Directorul curent in care se afla aplicatia

runProgram();

# ================================================================
#   Functia createFile()
# =================================================================
sub createFile {
    print "Enter your file name: ";
    $filename = <STDIN>;
    chomp $filename;
    
    # This changes perl directory  and moves you inside directory.
    chdir( $dir ) or die "Couldn't go inside $dir directory, $!";
    
    my $author = 'Mihai Cornel mhcrnl@gmail.com';
    my $fh;

    open($fh, '>', $filename) or die "Could not open '$filename' $!";

    print $fh "#!/usr/bin/perl\n\n";
    print $fh "# Aceasta este o fila de cod perl $filename.\n";
    print $fh "# Autor: '$author'\n\n";
    print $fh "use strict;\n";
    print $fh "use warnings;\n\n";
    print $fh "print \"Salut din perl\";";
    close $fh;

    print "Salut din PERL, operatie reusita.\n";
}
# ===================================================================
#   Functia Help()
# ===================================================================
sub Help {
    print "Aceasta este functia Help(). ";
    print "USE: \n";
    print "Insert input in form of my_perl_file.pl \n";
}
# ===================================================================
#   Functia Meniu()
# ===================================================================
sub Meniu {
    print "1. Help meniu.\n";
    print "2. Create file.\n";
    print "3. Read file.\n";
    print "4. Create directory.\n";
    print "5. Create README.md.\n";
    print "6. Create gitpush.sh file. \n";
    print "7. Execute command gitpush.sh \n";
    print "8. Close program.\n";
    
    print "Insert your choice(1-8): ";
    my $prompt = <STDIN>;
    return $prompt;
}
# ==================================================================
#   Functia runProgram()
# ==================================================================
sub runProgram {
    my $choice;
    while (1) {
        $choice = Meniu();
        if($choice == 1) {
            # === Functia Help() apelare 
            Help();
        } elsif ($choice == 2) {
            createFile();
        } elsif ($choice == 3) {
            # === Apelarea functiei readFile() 
            readFile();
        } elsif ($choice == 4) {
            # === Apelarea functiei createDirectory()
            createDirectory();
        } elsif ($choice == 5){
            # === Apelarea functiei createReadme()
            createReadme();
        } elsif ($choice == 6){
            createGitpush();
        } elsif ($choice == 7) {
            system("./gitpush.sh");
        } elsif ($choice == 8) {
            exit();
        } else {
            print "Invalid entry try again.";
        }
    }
    print "Executarea programului s-a terminat.End.";
}
# ===================================================================
#   Functia readFile()
# ===================================================================
sub readFile {
    open(DATA, '<', $filename) or die "Could not open '$filename' $!";
    my @lines = <DATA>;
    print "@lines\n";
    #close(DATA):
}
# =====================================================================
#    Functia createDirectory() - create a new Directory
# =====================================================================
sub createDirectory {
    print "Enter the name of Directory: ";
    $dir = <STDIN>;
    chomp $dir;
    
    mkdir($dir) or die "Couldn't create $dir directory, $!"; 
    print "Directory created with success!";
}
# =====================================================================
#       Functia createReadme() - create file README.md
# ======================================================================
sub createReadme
{
    my $readme = "README.md";
    my $fr;
    print "$dir\n";
    $dir = cwd; # Intra in directorul curent  
    # This changes perl directory  and moves you inside directory.
    chdir($dir) or die "Couldn't go inside $dir directory, $!"; 
    # This create the file README.md  
    open($fr, '>', $readme) or die "Could not open '$readme' $!"; 
    print $fr "#This is the README file." ;   
    
}
# =========================================================================
#       Functia createGitpush() - create file gitpush.sh
# =========================================================================
sub createGitpush
{
    my $gitpush = "gitpush.sh";
    my $fg;
    $dir = cwd;
    # This changes perl directory  and moves you inside directory.
    chdir($dir) or die "Couldn't go inside $dir directory, $!"; 
    # This create the file README.md  
    open($fg, '>', $gitpush) or die "Could not open '$gitpush' $!"; 
    
    print $fg "#!/bin/bash \n";
    print $fg "DATE=`date` \n";
    print $fg "git add . \n";
    print $fg 'git commit -m "$DATE"';
    print $fg "\n git push origin master \n";
    
    print "$gitpush create with success!!";
}





