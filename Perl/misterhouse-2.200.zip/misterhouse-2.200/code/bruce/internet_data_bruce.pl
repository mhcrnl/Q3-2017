

                                # Make sure we have current tv data for today
#if (time_cron('58 5 * * *')) {
#    run_voice_cmd 'reget tv grid data for today';
#}
