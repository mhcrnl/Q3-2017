
# Stay connected to im servers

if (new_minute 10) {
#    run_voice_cmd 'Connect to AOL';
#    run_voice_cmd 'Connect to MSN';
#   run_voice_cmd 'Connect to jabber';
}
