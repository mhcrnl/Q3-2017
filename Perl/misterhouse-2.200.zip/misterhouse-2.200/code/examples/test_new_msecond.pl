
my $ms_count = 0;
if ($New_Msecond_100) {
#if ($New_Msecond_250) {
#f ($New_Msecond_500) {
    print ++$ms_count;
    print "\n"    if $New_Second;
    $ms_count = 0 if $New_Second;
}
