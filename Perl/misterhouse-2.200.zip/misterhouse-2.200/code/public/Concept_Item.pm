# Inheritence package for Concept alarm items
# All Concept_items are in fact Generic_Items, unless declared or defined here

use strict;

package Concept_Item;

@Concept_Item::ISA = ('Generic_Item');

1;

