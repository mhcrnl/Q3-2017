# Category=Test
 
$v_test1 = new Voice_Cmd("Say hi");

speak "Hi Nick" if said $v_test1;
