# Category = MisterHouse

#@ An empty code file, sometimes useful for debug when you 
#@ want to run mh with no code files:  mh empty.pl



