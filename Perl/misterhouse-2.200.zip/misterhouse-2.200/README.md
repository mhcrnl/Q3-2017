misterhouse
===========

Perl open source home automation program. It's fun, it's free, and it's entirely geeky.

A quickstart guide is documented [here](https://github.com/hollie/misterhouse/wiki/Getting-started).

The Misterhouse wiki with more information is located here: http://misterhouse.wikispaces.com/