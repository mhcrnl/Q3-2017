package Kephra::Macro;
our $VERSION = '0.00';

use strict;
use warnings; 


sub create_from_cmd_list {
	return;
}

1;