#!/usr/bin/perl

# Aceasta este o fila de cod perl perlcode.pl.
# Autor: 'Mihai Cornel mhcrnl@gmail.com'

use strict;
use warnings;

print "Salut din perl";