#! /usr/bin/perl
use strict;
use warnings;
use Scalar::Util qw(looks_like_number); #almost always useful
=pod
	 Filename: test.pl.
	 Autor: 'Mihai Cornel mhcrnl@gmail.com'
Create time: Mon Oct  2 10:45:53 2017
=cut
print "Salut din perl";