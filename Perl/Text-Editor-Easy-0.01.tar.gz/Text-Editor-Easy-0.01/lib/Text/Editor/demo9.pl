#
# And what now ?
#
# If you want to go further,
# you may have a look at the code
# (try F5 for that, unless this editor is too ugly).
# Key.pm is executed when you type a
# key function : simple, isn't it ?
# But static, sorry : you'll have to restart
# the program if you make any change there.
#
# The module interface is not yet
# finalized, but the more I use the module
# to write the program, the more (I think)
# I understand what should be
# the interface, and the more I test it too.
#
#
# Before version 1.0, don't send me bugs,
# only constructive comments, like :
# "A much better module than you are
# writing has been delivered
# 234 years ago at CPAN and is called ..."
#
# Please tell me ! I didn't want to write
# that ugly editor ! I only wanted to use
# an existing one ! I swear it !
#
