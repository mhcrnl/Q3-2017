#
# How ugly !
#
# These demos will introduce you to :
#   - the perl Editor program
#       (in which you should be now, if my
#       readme is readable)
#   - the editor perl module which is
#       intensively used by the program
#       (a few objects created by this
#       "full of bugs" module should be
#       running silently now, be careful of
#       unpredictable effects !)
#
#
# As a perl programmer, and in the future
# (of course), you might be interested
# by these 2 elements  :
#
#   - by the program used to edit your code
#     and execute it. You'll have :
#         - powerful perl regular search
#         - maybe one of the most powerful
#           macro langage (this langage,
#           perl of course, is indeed the same
#           that is used to write the program)
#           It didn't cost me a lot since perl
#           has a powerful "eval".
#
#   - by the module itself to write very
#     quickly interactive graphical
#     applications :
#         - you'll be able to write your own
#           "highlight" subs
#         - you'll be able to redirect events,
#           keys... knowing nothing about Tk
#           (a knowledge of perl
#           would help, though)
#
# Let's start now !
#
# You can move your mouse over the
# "Editor_out" tab on the right
# This will show you all the displays
# that this running program is making.
# We may call that the log of this
# Editor program.
#
# This log is "interactive" : moving
# your mouse over one display
# will send you to the line of the file
# that generated it.
# Beware ! At the moment, this can
# be very long because the line search
# is not really done.
#
# The Eval_out will be used later.
#
# Now, this demo is finished, you can
# mouve you mouse over "demo2.pl"
#
