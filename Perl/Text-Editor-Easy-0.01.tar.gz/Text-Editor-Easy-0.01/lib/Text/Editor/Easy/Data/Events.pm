return (

    # Ev�nements d'�diteurs
    'cursor_set_last' => 'Editor',
    'motion_last'     => 'Editor',
    'on_top_last'     => 'Editor',
    'insert_last'     => 'Editor',

    # Ev�nements de zones
    'on_top_editor_change' => 'Zone',
);
