#!/env/bin/perl

use lib "/MyPerlCode/EVZOnline-RSSreader/lib/EVZOnline/";

#use EVZOnline::RSSreader;
EVZOnline::RSSreader;