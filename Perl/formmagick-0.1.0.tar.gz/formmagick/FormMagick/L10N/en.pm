#!/usr/bin/perl -w

package FormMagick::L10N::en; # English
@ISA = qw(FormMagick::L10N);

%Lexicon = (
	"My form application"
		=> "My form application"
);

1;

