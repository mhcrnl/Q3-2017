#!/usr/bin/perl -w

package FormMagick::L10N::fr; # French
@ISA = qw(FormMagick::L10N);

%Lexicon = (
	"My form application"
		=> "Je ne sais pas les mots."
);

1;

