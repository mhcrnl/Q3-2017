#!/bin/sh
echo TIMES UP | osd_cat -p middle -A center -f '-*-helvetica-*-r-*-*-34-*-*-*-*-*-*-*' -d 10 -s 2 -S green &
qiv ~/scripts/timesup.png &
