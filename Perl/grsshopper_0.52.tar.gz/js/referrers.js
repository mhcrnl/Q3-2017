function write_ref() {
   document.write("This script no longer functions");
}
write_ref();
