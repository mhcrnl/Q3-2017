$rDef = {
  'icon' => 'default',
  'geom' => '0',
  'file' => 'Panedwindow',
  'attr' => {},
  'classname' => 'Panedwindow',
  'use' => 'Tk::Panedwindow',
  'nonVisual' => undef,
  'defaultgeometrymanager' => '',
  'balloon' => '1',
  'defaultwidgetoptions' => undef,
  'defaultgeometryoptions' => undef
};
