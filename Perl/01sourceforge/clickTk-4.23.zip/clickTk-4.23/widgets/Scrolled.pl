$rDef = {
  'icon' => 'Scrolled',
  'geom' => 1,
  'file' => 'Scrolled',
  'attr' => {
    '-scrollbars' => 'menu(s|os|e|oe|w|ow|n|on|se|ose|soe|osoe|sw|osw|sow|ne|one|noe|onoe|nw|onw|now|onow)',
	'-scrolledclass' => 'scrollableclassname'
	},
  'classname' => 'Scrolled',
  'defaultscrolledclass' => 'Text',
  'use' => ' ',
  'nonVisual' => 0,
  'defaultgeometrymanager' => 'pack',
  'balloon' => 1,
  'defaultgeometryoptions' => '',
  'defaultwidgetoptions' => '-scrollbars, se'
};

