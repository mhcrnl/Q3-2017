$rDef = {
  'geom' => 0,
  'use' => ' ',			## do not gen use statement
  'balloon' => 0,
  'attr' => {}
};
