$rDef = {
  'geom' => 1,
  'balloon' => 1,
  'use' => 'NumEntry',
  'classname' => 'NumEntry',
  'attr' => {
    '-background' => 'color',
    '-foreground' => 'color',
    '-width' => 'int+',
    '-relief' => 'relief',
    '-textvariable' => 'text',
    '-incvalue' => 'int+',
    '-maxvalue' => 'int+',
    '-minvalue' => 'int+'
  }
};
