$rDef = {
  'icon' => 'default',
  'nonVisual' => '1',
  'geom' => '0',
  'file' => 'after',
  'attr' => {},
  'classname' => 'after',
  'use' => 'Tk::After',
  'defaultgeometrymanager' => ' ',
  'balloon' => '0',
  'defaultgeometryoptions' => undef,
  'defaultwidgetoptions' => undef
};
