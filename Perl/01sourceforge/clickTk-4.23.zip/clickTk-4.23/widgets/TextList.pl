$rDef = {
  'icon' => 'TextList',
  'geom' => '1',
  'file' => 'TextList',
  'attr' => undef,
  'classname' => 'TextList',
  'use' => 'Tk::TextList',
  'nonVisual' => undef,
  'defaultgeometrymanager' => 'pack',
  'balloon' => undef,
  'defaultgeometryoptions' => '-side, \'top\'',
  'defaultwidgetoptions' => undef
};
