$rDef = {
  'icon' => 'default',
  'geom' => '0',
  'file' => 'JPEG',
  'attr' => {},
  'classname' => 'JPEG',
  'use' => 'Tk::JPEG',
  'nonVisual' => '1',
  'defaultgeometrymanager' => '',
  'balloon' => '0',
  'defaultwidgetoptions' => undef,
  'defaultgeometryoptions' => undef
};
