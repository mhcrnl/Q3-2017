$rDef = {
  'icon' => 'packAdjust',
  'geom' => '0',
  'file' => 'packAdjust',
  'attr' => {
    '-side' => 'side'
  },
  'classname' => 'packAdjust',
  'use' => 'Tk::Adjuster',
  'defaultgeometrymanager' => 'pack',
  'balloon' => '0',
  'defaultgeometryoptions' => undef,
  'defaultwidgetoptions' => undef
};
