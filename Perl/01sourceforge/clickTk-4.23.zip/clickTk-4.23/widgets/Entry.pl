$rDef = {
  'geom' => 1,
  'balloon' => 1,
  'attr' => {
    '-background' => 'color',
	'-font' => 'font',
    '-foreground' => 'color',
    '-state' => 'menu(normal|disabled)',
    '-width' => 'int+',
    '-borderwidth' => 'int+',
    '-justify' => 'justify',
    '-show' => 'text',
    '-relief' => 'relief',
    '-textvariable' => 'variable'
  }
};
