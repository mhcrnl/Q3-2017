$rDef = {
  'icon' => 'default',
  'geom' => '0',
  'file' => 'PNG',
  'attr' => {},
  'classname' => 'PNG',
  'use' => 'Tk::PNG',
  'nonVisual' => '1',
  'defaultgeometrymanager' => '',
  'balloon' => '0',
  'defaultwidgetoptions' => undef,
  'defaultgeometryoptions' => undef
};
