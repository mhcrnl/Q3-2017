$rDef = {
  'icon' => 'nonvisual',
  'geom' => 0,
  'file' => 'JPEG_temp',
  'attr' => {},
  'classname' => 'JPEG',
  'use' => 'JPEG',
  'nonVisual' => 1,
  'defaultgeometrymanager' => 'pack',
  'balloon' => 1,
  'defaultwidgetoptions' => '',
  'defaultgeometryoptions' => ''
};
