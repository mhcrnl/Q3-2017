$rDef = {
  'icon' => 'nonvisual',
  'geom' => 0,
  'file' => 'Scrolled_temp',
  'attr' => {},
  'classname' => 'Scrolled',
  'use' => 'Scrolled',
  'nonVisual' => 1,
  'defaultgeometrymanager' => 'pack',
  'balloon' => 1,
  'defaultgeometryoptions' => '',
  'defaultwidgetoptions' => ''
};
