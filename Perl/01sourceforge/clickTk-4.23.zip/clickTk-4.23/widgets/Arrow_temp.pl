$rDef = {
  'icon' => 'nonvisual',
  'geom' => 0,
  'file' => 'Arrow_temp',
  'attr' => {},
  'classname' => 'Arrow',
  'use' => 'Arrow',
  'nonVisual' => 1,
  'defaultgeometrymanager' => 'pack',
  'balloon' => 1,
  'defaultwidgetoptions' => '',
  'defaultgeometryoptions' => ''
};
