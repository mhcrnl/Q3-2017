$rDef = {
  'geom' => 1,
  'balloon' => 1,
  'attr' => {
    '-anchor' => 'anchor',
    '-pady' => 'int+',
    '-background' => 'color',
    '-foreground' => 'color',
    '-width' => 'int+',
    '-borderwidth' => 'int+',
    '-justify' => 'justify',
	'-font' => 'font',
    '-text' => 'text',
    '-relief' => 'relief',
    '-aspect' => 'int+',
    '-padx' => 'int+'
  }
};
