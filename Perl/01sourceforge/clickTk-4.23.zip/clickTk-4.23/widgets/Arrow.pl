$rDef = {
  'icon' => 'default',
  'geom' => '0',
  'file' => 'Arrow',
  'attr' => {-X1,0, -Y1,0, -X2,0, -Y2,0 , -color,'white'},
  'classname' => 'Arrow',
  'pathName' => 'C:\\Dokumente und Einstellungen\\marco\\Projekte\\Perl experience\\Tk\\GD\\GD-Arrow-0.01\\lib',
  'use' => 'GD::Arrow',
  'nonVisual' => '1',
  'defaultgeometrymanager' => '',
  'balloon' => '0',
  'defaultwidgetoptions' => undef,
  'defaultgeometryoptions' => undef
};
