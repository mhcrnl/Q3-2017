$rDef = {
  'geom' => 1,
  'balloon' => 1,
  'defaultgeometrymanager' => 'pack',
  'defaultgeometryoptions' => "-side => top, -fill => both, -expand => 1, -anchor => nw",
  'defaultwidgetoptions' => "-relief => solid, -borderwidth => 1",
  'attr' => {
    '-height' => 'int+',
    '-borderwidth' => 'int+',
    '-background' => 'color',
    '-label' => 'text',
    '-relief' => 'relief',
    '-width' => 'int+'
  }
};
