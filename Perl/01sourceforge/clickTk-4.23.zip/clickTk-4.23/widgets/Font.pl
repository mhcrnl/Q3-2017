$rDef = {
  'icon' => 'default',
  'geom' => '0',
  'file' => 'Font',
  'attr' => {
    '-overstrike' => 'menu(0|1)',
    '-underline' => 'menu(0|1)',
    '-family' => 'text',
    '-size' => 'int+',
    '-slant' => 'menu(roman|italic)'
  },
  'classname' => 'Font',
  'pathName' => undef,
  'use' => 'Tk::Font',
  'nonVisual' => '1',
  'defaultgeometrymanager' => '',
  'balloon' => '0',
  'defaultwidgetoptions' => undef,
  'defaultgeometryoptions' => undef
};
