$rDef = {
  'icon' => 'nonvisual',
  'geom' => 0,
  'file' => 'x_nonVisual_temp',
  'attr' => {},
  'classname' => 'x_nonVisual',
  'use' => 'x_nonVisual',
  'nonVisual' => 1,
  'defaultgeometrymanager' => 'pack',
  'balloon' => 1,
  'defaultgeometryoptions' => '',
  'defaultwidgetoptions' => ''
};
