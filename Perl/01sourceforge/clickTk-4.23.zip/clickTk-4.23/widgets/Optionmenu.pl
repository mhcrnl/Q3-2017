$rDef = {
  'geom' => 1,
  'balloon' => 0,
  'attr' => {
    '-command' => 'callback',
    '-variable' => 'text'
  }
};
