$rDef = {
  'geom' => 0,
  'use' => ' ',
  'balloon' => 0,
  'attr' => {
    '-underline' => 'int+',
    '-background' => 'color',
    '-accelerator' => 'text',
    '-label' => 'text',
    '-foreground' => 'color',
    '-command' => 'callback'
  }
};
