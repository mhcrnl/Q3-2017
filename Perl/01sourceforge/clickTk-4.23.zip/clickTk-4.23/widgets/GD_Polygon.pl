$rDef = {
  'icon' => 'default',
  'geom' => '0',
  'file' => 'GD_Polygon',
  'attr' => {},
  'classname' => 'GD::Polygon',
  'pathName' => undef,
  'use' => 'GD::Polygon',
  'nonVisual' => '1',
  'defaultgeometrymanager' => '',
  'balloon' => '0',
  'defaultwidgetoptions' => undef,
  'defaultgeometryoptions' => undef
};
