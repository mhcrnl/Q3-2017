$rDef = {
  'geom' => 1,
  'balloon' => 0,
  'attr' => {
    '-height' => 'int+',
    '-borderwidth' => 'int+',
    '-background' => 'color',
    '-label' => 'text',
    '-relief' => 'relief',
    '-labelside' => 'menu(left|right|top|bottom|acrosstop)',
    '-width' => 'int+'
  }
};
