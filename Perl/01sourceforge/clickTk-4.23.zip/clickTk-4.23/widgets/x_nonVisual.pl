$rDef = {
  'icon' => 'nonvisual',
  'geom' => '0',
  'file' => 'x_nonVisual',
  'attr' => {
    '-debug' => 'menu(0|1)',
    '-name' => 'text',
    '-counter' => 'int+'
  },
  'classname' => 'x_nonVisual',
  'use' => 'x_nonVisual',
  'nonVisual' => '1',
  'defaultgeometrymanager' => '',
  'balloon' => '1',
  'defaultgeometryoptions' => '',
  'defaultwidgetoptions' => ''
};
