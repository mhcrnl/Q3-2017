$rDef = {
  'geom' => 0,
  'balloon' => 0,
  'attr' => {
    '-borderwidth' => 'int+',
    '-background' => 'color',
    '-relief' => 'relief',
    '-tearoff' => 'menu(0|1)',
    '-foreground' => 'color'
  }
};
