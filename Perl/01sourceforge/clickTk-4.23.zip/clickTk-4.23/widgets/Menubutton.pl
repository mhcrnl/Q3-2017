$rDef = {
  'geom' => 1,
  'balloon' => 0,
  'attr' => {
    '-anchor' => 'anchor',
    '-underline' => 'int+',
    '-pady' => 'int+',
    '-background' => 'color',
    '-foreground' => 'color',
    '-state' => 'menu(normal|active|disabled)',
    '-width' => 'int+',
    '-borderwidth' => 'int+',
    '-justify' => 'justify',
    '-relief' => 'relief',
    '-text' => 'text',
    '-textvariable' => 'text',
    '-padx' => 'int+'
  }
};
