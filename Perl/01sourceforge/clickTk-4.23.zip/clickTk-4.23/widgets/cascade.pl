$rDef = {
  'geom' => 0,
  'balloon' => 1,
  'use' => ' ',			## do not gen use statement
  'attr' => {
    '-underline' => 'int+',
    '-background' => 'color',
    '-accelerator' => 'text',
    '-label' => 'text',
    '-foreground' => 'color'
  }
};
