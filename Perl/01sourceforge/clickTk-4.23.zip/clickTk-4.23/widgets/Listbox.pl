$rDef = {
  'geom' => 1,
  'balloon' => 0,
  'attr' => {
    '-background' => 'color',
    '-foreground' => 'color',
    '-width' => 'int+',
    '-setgrid' => 'menu(0|1)',
    '-borderwidth' => 'int+',
	'-font' => 'font',
    '-height' => 'int+',
    '-selectmode' => 'menu(single|browse|multiple|extended)',
    '-relief' => 'relief'
  }
};
