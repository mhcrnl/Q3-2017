$rDef = {
  'geom' => 0,
  'use' => ' ',
  'balloon' => 0,
  'attr' => {
    '-anchor' => 'anchor',
    '-underline' => 'int+',
    '-raisecmd' => 'callback',
    '-wraplength' => 'int+',
    '-justify' => 'justify',
    '-label' => 'text',
    '-createcmd' => 'callback',
    '-state' => 'menu(normal|disabled)'
  }
};
