$rDef = {
  'geom' => 1,
  'balloon' => 1,
  'attr' => {
    '-setgrid' => 'menu(0|1)',
    '-takefocus' => 'menu(0|1)',
    '-pady' => 'int+',
    '-height' => 'int+',
    '-borderwidth' => 'int+',
    '-background' => 'color',
	'-font' => 'font',
    '-foreground' => 'color',
    '-wrap' => 'menu(none|char|word)',
    '-padx' => 'int+',
    '-width' => 'int+',
    '-state' => 'menu(normal|disabled)'
  }
};
