$rDef = {
  'icon' => 'default',
  'geom' => '0',
  'file' => 'Animation',
  'attr' => {
    '-file' => 'file',
    '-height' => 'int',
    '-format' => 'text',
    '-palette' => 'text',
    '-width' => 'int+'
  },
  'classname' => 'Animation',
  'pathName' => undef,
  'use' => 'Tk::Animation',
  'nonVisual' => undef,
  'defaultgeometrymanager' => '',
  'balloon' => '0',
  'defaultwidgetoptions' => '',
  'defaultgeometryoptions' => undef
};
