$rDef = {
  'icon' => 'default',
  'geom' => '0',
  'file' => 'arrowSimple',
  'attr' => {
    '-X1' => 'int+',
    '-Y1' => 'int+',
    '-X2' => 'int+',
    '-Y2' => 'int+',
    '-color' => 'color'
  },
  'classname' => 'arrowSimple',
  'pathName' => 'C:\\Dokumente und Einstellungen\\marco\\Projekte\\Perl experience\\Tk\\GD\\GD-Arrow-0.01\\lib\\',
  'use' => 'GD::arrowSimple',
  'nonVisual' => '1',
  'defaultgeometrymanager' => '',
  'balloon' => '0',
  'defaultwidgetoptions' => '',
  'defaultgeometryoptions' => undef
};
