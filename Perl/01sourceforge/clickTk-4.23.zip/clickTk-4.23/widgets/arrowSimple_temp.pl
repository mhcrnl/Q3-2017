$rDef = {
  'icon' => 'nonvisual',
  'geom' => 0,
  'file' => 'arrowSimple_temp',
  'attr' => {},
  'classname' => 'arrowSimple',
  'use' => 'arrowSimple',
  'nonVisual' => 1,
  'defaultgeometrymanager' => 'pack',
  'balloon' => 1,
  'defaultwidgetoptions' => '',
  'defaultgeometryoptions' => ''
};
