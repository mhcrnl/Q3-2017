$rDef = {
  'icon' => 'xPhoto',
  'geom' => '0',
  'file' => 'Photo',
  'attr' => {
    '-file' => 'file',
    '-height' => 'int+',
    '-width' => 'int+'
  },
  'classname' => 'Photo',
  'use' => 'Tk::Photo',
  'nonVisual' => '0',
  'defaultgeometrymanager' => '',
  'balloon' => '0',
  'defaultgeometryoptions' => undef,
  'defaultwidgetoptions' => undef
};
