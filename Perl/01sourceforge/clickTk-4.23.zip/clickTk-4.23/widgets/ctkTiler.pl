$rDef = {
  'icon' => 'default',
  'geom' => '1',
  'file' => 'ctkTiler',
  'attr' => {
    '-columns' => 'int+',
    '-rows' => 'int+',
    '-height' => 'int+',
    '-bg' => 'color',
    '-relief' => 'relief',
    '-width' => 'int+'
  },
  'classname' => 'ctkTiler',
  'pathName' => undef,
  'use' => 'Tk::ctkTiler',
  'nonVisual' => undef,
  'defaultgeometrymanager' => 'pack',
  'balloon' => '1',
  'defaultwidgetoptions' => undef,
  'defaultgeometryoptions' => undef
};
