#! /usr/bin/perl
use strict;
use warnings;
use Tk;
use LWP::Simple;
use Cwd;
# =============================================================WINDOW
my $mw = new MainWindow;
$mw->title("Perl/Tk Download Files");
$mw->geometry("550x150+0+0");
$mw->configure(-menu => my $menubar = $mw ->Menu);

my $file = $menubar->cascade(-label => '~File'); 
my $edit = $menubar->cascade(-label => '~Edit'); 
my $help = $menubar->cascade(-label => '~Help'); 

my $new = $file->cascade( -label => 'New', -accelerator=>'Ctrl-n', -underline=>0,);
$file->separator;
$file->command( -label=>'Open', -accelerator=>'Ctrl-o', -underline=>0,);
$file->command( -label=>'Save', -accelerator=>'Ctrl-s', -underline=>0,);
$file->command( -label=>'Save As...', -accelerator=>'Ctrl-a', -underline=>0,);
$file->command( -label=>'Close', -accelerator=>'Ctrl-w', -underline=>0, -command=>\&exitProgram,);
# ============================================================LABEL
my $l_url = $mw -> Label(-text=>"URL: ") ; # -> pack(-side=>'left');
my $l_file = $mw -> Label(-text=>"File: ") ;
# ============================================================ENTRY
my $e_start = $mw->Entry(-width=>50); #->pack(-side=>'left');
my $e_file = $mw->Entry();
# ==========================================================BUTTONS
my $button = $mw -> Button(-text => "    Clear     ", -command =>\&clear);#-> pack(-side=>'left');
my $b_get = $mw -> Button(-text => "Download", -command =>\&download);
my $bpush = $mw->Button(-text=>"SourceForge", -command=>\&pushCode);
# ==========================================================GRID
$l_url->grid(-row=>0, -column=>0);
$e_start->grid(-row=>0, -column=>1);
$button->grid(-row=>0, -column=>2);

$l_file->grid(-row=>1, -column=>0);
$e_file->grid(-row=>1, -column=>1);
$b_get->grid(-row=>1, -column=>2);

$bpush->grid(-row=>2, -column=>0);

MainLoop;

sub pushCode {
        my $gitpush = cwd;
        system("./gitpush.sh");
}

sub clear{
            # $e_start->insert(end, " ");
            # $e_file->insert(end, " ");
 }

sub download{
        my $url = $e_start->get();
        my $file = $e_file->get();
        getstore($url, $file);
}

sub exitProgram {
    $mw -> messageBox(-message=>"La revedere!");
    exit;
}
1;
__END__
=pod
ABOUT:
    Window with a message box.
RESURSE:
    http://bin-co.com/perl/perl_tk_tutorial/perl_tk_tutorial.pdf
RUN:
    $ perl 02PTk.pl
    
=cut