#! /usr/bin/perl
# Pragmas
use strict;
use warnings;
# Modul exists
use LWP::Simple;
print "Simple module to save web pages in any format(html, source code).";
# URL to save
print "Insert the website URL: ";
my $url = <STDIN>;
# File name to save url
print "Insert the name of file to save the url: "; 
my $file = <STDIN> ;
# Function to save web file
getstore($url, $file);
