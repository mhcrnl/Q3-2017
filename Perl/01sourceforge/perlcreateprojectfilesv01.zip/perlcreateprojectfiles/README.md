#Create Perl Structure Projects

This project contains two run files:

    1. perl_create_files.pl RUN: $perl perl_create_file.pl
    2. mhcrnl_run_gui.pl    RUN: $perl mhcrnl_run_gui.pl

##Templates folder contains:

    Console.pl
    TkGui.pl
    Readme.md
    Class
        Class.pm
    Module
        Module.pm

This code in Templates must run.