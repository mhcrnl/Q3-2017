#--------------------------------------------------------------
# The DevDaily::Time Perl module.
# Free to use as a template for creating your own Perl modules.
#--------------------------------------------------------------
package Modules::Module;
require Exporter;

our @ISA     = qw(Exporter);
our @EXPORT  = qw(get_time_suffix);   # symbols to be exported by default (space-separated)
our $VERSION = 1.00;                  # version number

use POSIX 'strftime';

#----------------
# get_time_suffix
#----------------

# returns a string formatted like "2008.08.18.12.31.56"
# requires "use POSIX 'strftime';"
sub get_time_suffix
{
  return strftime( '%Y.%m.%d.%H.%M.%S', localtime(time()) );
}

1;

