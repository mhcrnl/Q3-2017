#! /usr/bin/perl

use strict;
use warnings;
# my modules
use Modules::Module; 
use Classes::Class;

print "WELLCOME TO PERL CONSOLE SCRIPT\n";
Snake->new('Sammy the Python')->move(5);
print &get_time_suffix();
print "\n"

__END__

=pod



=cut 
