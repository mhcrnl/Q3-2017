#! /usr/bin/perl

use strict;
use warnings;

require Class::Class;

print "WELLCOME TO PERL CONSOLE SCRIPT";
Snake->new('Sammy the Python')->move(5);

__END__

=pod



=cut 
