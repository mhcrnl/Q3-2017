#! /usr/bin/perl
use strict;
use warnings;
use Tk;
# get pathname of current working directory
use Cwd;
# ========================================================GLOBAL VARIABLES
# returns current working directory
my  $dir = getcwd;
# directory to save class file (pm)
my $class_dir;
# directory to save module file (pm)
my $module_dir;
# creates main window
my $mw = new MainWindow;
$mw->title("Create Perl Programs");
$mw->geometry("450x350+0+0");
$mw->configure(-menu => my $menubar = $mw ->Menu);

my $file = $menubar->cascade(-label => '~File'); 
my $edit = $menubar->cascade(-label => '~Edit'); 
my $help = $menubar->cascade(-label => '~Help'); 

my $new = $file->cascade( -label => 'New', -accelerator=>'Ctrl-n', -underline=>0,);
$file->separator;
$file->command( -label=>'Open', -accelerator=>'Ctrl-o', -underline=>0,);
$file->command( -label=>'Save', -accelerator=>'Ctrl-s', -underline=>0,);
$file->command( -label=>'Save As...', -accelerator=>'Ctrl-a', -underline=>0,);
$file->command( -label=>'Close', -accelerator=>'Ctrl-w', -underline=>0, -command=>\&exitProgram,);
# ============================================================LABEL
my $label   = $mw -> Label(-text=>"Project folder:  "); # -> pack(-side=>'left');
my $label1 = $mw -> Label(-text=>"File :                 "); 
my $label2 = $mw -> Label(-text=>"Class folder :   "); 
my $label3 = $mw -> Label(-text=>"Class file :        "); 
my $label4 = $mw -> Label(-text=>"Module folder :"); 
my $label5 = $mw -> Label(-text=>"Module file :    "); 
my $label6 = $mw -> Label(-text=>"File :                "); 
my $label7 = $mw -> Label(-text=>"File :                "); 
# ============================================================ENTRY
my $eDir   = $mw->Entry(-textvariable=>"NewPerlProject"); #->pack(-side=>'left');
my $eDir1 = $mw->Entry(-textvariable=>"README.md");
my $eDir2 = $mw->Entry(-textvariable=>"Classes");
my $eDir3 = $mw->Entry(-textvariable=>"Class.pm");
my $eDir4 = $mw->Entry(-textvariable=>"Modules");
my $eDir5 = $mw->Entry(-textvariable=>"Module.pm");
my $eDir6 = $mw->Entry(-textvariable=>"RunConsole.pl");
my $eDir7 = $mw->Entry(-textvariable=>"RunTkGui.pl");
# ==========================================================BUTTONS
# create new base project folder  
my $button   = $mw -> Button(-text => "Create", -command =>\&createBaseFolder); #-> pack(-side=>'left');
my $button1 = $mw -> Button(-text => "Create", -command =>\&createReadme);
my $button2 = $mw -> Button(-text => "Create", -command =>\&createClassFolder);
my $button3 = $mw -> Button(-text => "Create", -command =>\&createClassFile);
my $button4 = $mw -> Button(-text => "Create", -command =>\&createModuleFolder);
my $button5 = $mw -> Button(-text => "Create", -command =>\&createModuleFile);
my $button6 = $mw -> Button(-text => "Create", -command =>\&createRunConsole);
my $button7 = $mw -> Button(-text => "Create", -command =>\&createRunTkGui);

my $bRun = $mw->Button(-text => "Run", -command=>\&runConsole);
# ============================================================GRID
$label->grid(-row=>0, -column=>0);
$eDir->grid(-row=>0, -column=>1);
$button ->grid(-row=>0, -column=>2);

$label6    ->grid(-row=>1, -column=>0);
$eDir6     ->grid(-row=>1, -column=>1);
$button6  ->grid(-row=>1, -column=>2);
#$bRun       ->grid(-row=>1, -column=>3);

$label7    ->grid(-row=>2, -column=>0);
$eDir7    ->grid(-row=>2, -column=>1);
$button7 ->grid(-row=>2, -column=>2);

$label1    ->grid(-row=>3, -column=>0);
$eDir1     ->grid(-row=>3, -column=>1);
$button1 ->grid(-row=>3, -column=>2);

$label2    ->grid(-row=>4, -column=>0);
$eDir2     ->grid(-row=>4, -column=>1);
$button2 ->grid(-row=>4, -column=>2);

$label3    ->grid(-row=>5, -column=>0);
$eDir3     ->grid(-row=>5, -column=>1);
$button3 ->grid(-row=>5, -column=>2);

$label4   ->grid(-row=>6, -column=>0);
$eDir4     ->grid(-row=>6, -column=>1);
$button4 ->grid(-row=>6, -column=>2);

$label5    ->grid(-row=>7, -column=>0);
$eDir5     ->grid(-row=>7, -column=>1);
$button5  ->grid(-row=>7, -column=>2);

MainLoop;

sub runConsole {
        my $comand = "perl ".$dir."/".$eDir->get()."/".$eDir6->get();
        system($comand);
    
}

sub createRunTkGui{
         my $readmeTemplate = getcwd."/Templates/TkGui.pl";
        my $readmeFolder = getcwd."/".$eDir->get()."/".$eDir7->get();
        # open file to read
        open(DATA1,"<$readmeTemplate");
        # open file to write
        open(DATA2, ">$readmeFolder");
        while(<DATA1>){
                print DATA2 $_;
         }
         close( DATA1);
         close (DATA2);
        #print "$readmeFolder";
        
}

sub createRunConsole{
         my $readmeTemplate = getcwd."/Templates/Console.pl";
        my $readmeFolder = getcwd."/".$eDir->get()."/".$eDir6->get();
        # open file to read
        open(DATA1,"<$readmeTemplate");
        # open file to write
        open(DATA2, ">$readmeFolder");
        while(<DATA1>){
                print DATA2 $_;
         }
         close( DATA1);
         close (DATA2);
        #print "$readmeFolder";
}

sub createModuleFile{
         my $readmeTemplate = getcwd."/Templates/Module/Module.pm";
        my $readmeFolder = getcwd."/".$eDir->get()."/".$eDir4->get()."/".$eDir5->get();
        # open file to read
        open(DATA1,"<$readmeTemplate");
        # open file to write
        open(DATA2, ">$readmeFolder");
        while(<DATA1>){
                print DATA2 $_;
         }
         close( DATA1);
         close (DATA2);
        #print "$readmeFolder";

}

sub createModuleFolder {
        # creates new directory and get the new directory
        $module_dir = $dir ."/".$eDir->get()."/".$eDir4->get();
        mkdir( $module_dir ) or die "Couldn't create $module_dir directory, $!";
        print "Directory: $module_dir created successfully!\n";
}

sub createClassFile {
       my $readmeTemplate = getcwd."/Templates/Class/Class.pm";
        my $readmeFolder = getcwd."/".$eDir->get()."/".$eDir2->get()."/".$eDir3->get();
        # open file to read
        open(DATA1,"<$readmeTemplate");
        # open file to write
        open(DATA2, ">$readmeFolder");
        while(<DATA1>){
                print DATA2 $_;
         }
         close( DATA1);
         close (DATA2);
        #print "$readmeFolder";
}

sub createClassFolder{
         # creates new directory and get the new directory
        $class_dir = getcwd."/".$eDir->get()."/".$eDir2->get();
        mkdir( $class_dir ) or die "Couldn't create $class_dir directory, $!";
        print "Directory: $class_dir created successfully!\n";
}

sub createReadme{
        my $readmeTemplate = getcwd."/Templates/README.md";
        my $readmeFolder = getcwd."/".$eDir->get()."/".$eDir1->get();
        # open file to read
        open(DATA1,"<$readmeTemplate");
        # open file to write
        open(DATA2, ">$readmeFolder");
        while(<DATA1>){
                print DATA2 $_;
         }
         close( DATA1);
         close (DATA2);
        #print "$readmeFolder";
}

sub createBaseFolder{
        # creates new directory and get the new directory
        $dir = $dir."/".$eDir->get();
        mkdir( $dir ) or die "Couldn't create $dir directory, $!";
        print "Directory created successfully!\n";
}

sub exitProgram {
    $mw -> messageBox(-message=>"La revedere!");
    exit;
}

1;
__END__
=pod
ABOUT:
    Window with a message box.
RESURSE:
    http://bin-co.com/perl/perl_tk_tutorial/perl_tk_tutorial.pdf
RUN:
    $ perl 02PTk.pl
    
=cut