package my_module.pm;

use strict;
use warnings;
use Exporter qw(import);
our @EXPORT_OK = qw(add multiply);
1;
