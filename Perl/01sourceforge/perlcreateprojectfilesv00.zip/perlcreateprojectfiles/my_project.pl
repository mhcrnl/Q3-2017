#! /usr/bin/perl
use strict;
use warnings;
use Scalar::Util qw(looks_like_number); #almost always useful
=pod
	 Filename: my_project.pl 
	 Autor: 'Mihai Cornel mhcrnl@gmail.com'
	 Create time: Mon Oct  9 08:56:00 2017
	 TODO:
=cut
# ===== ENTRY POINT 
print "Salut din perl";