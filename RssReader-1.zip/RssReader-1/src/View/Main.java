package View;

import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import Model.Rss;

public class Main{
	public static void main(String[] args) {
		
		new GUI();
	}
}
