***************************************************
* Author: Ryan McMullen
* Title: Frogger
***************************************************
* Run the Main class in the index package to start 
* the application.
***************************************************
* The leaderboard will only save up to 5 scores, 
* then you have to delete them manually in the 
* totalScores.txt file because I was too lazy to 
* code that myself.
***************************************************
* NOTE: You may not make any money from any art, 
* audio or code provided by me. This is strictly 
* for educational purposes only.
***************************************************