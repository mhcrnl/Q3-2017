Title: A jackpot Game
Description: well this is a jackpot game i made. it is really fun. beginners should look at the code cause it will really help you with C++. This is a must Download for all types of programmers. from newbie to expert it is fun.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=522&lngWId=3

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
