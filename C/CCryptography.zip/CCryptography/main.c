#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "crypto.h"

int main()
{
    printf("Hello world! Cryptography Application\n");

    char password[20];
    printf("Enter the password: ");
    scanf("%s", password);
    encrypt(password, 21);
    printf("Password encrypted: %s\n", password);
    decrypt(password, 21);
    printf("Password decrypted: %s\n", password);

    return 0;
}
