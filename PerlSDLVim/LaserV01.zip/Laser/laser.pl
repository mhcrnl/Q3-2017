#!/usr/bin/perl

use strict;
use warnings;

use SDL;
use SDL::Event;
use SDLx::App;

my $app = SDLx::App->new (
	w	=> 500,
	h	=> 500,
	title	=> 'SDL Laser',
	exit_on_quit => 1, 
);

my $laser = 0;

my $velocity = 10;

$app->add_event_handler( \&quit);
$app->add_move_handler( \&calculate_laser);
$app->add_show_handler( \&render_laser);

$app->run();

sub quit {
	my $event = shift;
	my $controller = shift;
	$controller->stop if $event->type == SDL_QUIT;
}

sub calculate_laser {
	my ( $step, $app, $t ) = @_;
	$laser += $velocity * $step;
	$laser = 0 if $laser > $app->w;
}

sub render_laser {
	my ( $delta, $app ) = @_;
	$app->draw_rect( [0, 0, $app->w, $app->h], 0);
	$app->draw_rect( [$laser, $app->h/2, 10, 2], [250, 0, 0, 255]);
	
	$app->update();
}