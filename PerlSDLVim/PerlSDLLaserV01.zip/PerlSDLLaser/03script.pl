#!/usr/bin/perl
# ------------------------------------------------------------------------
# file: 03script.pl
# date: 15/11/2017
# author : mhcrnl@gmail.com
# SDL::Tutorial - introduction to perl SDL
# site: sdl.perl.org
# ------------------------------------------------------------------------
use strict;
use warnings;

use SDL;
use SDL::Event;
# -------------SDLx::App initialize video and create a surface(400x400x16)
use SDLx::App;
# --------------------------------------------------------Variabile globale
my $app = SDLx::App->
    new
    (
        width        => 400,
        height       => 400,
        depth        => 16,
        title        => 'My Perl/SDL Laser Program.',
        exit_on_quit => 1,
    );
# ---- color constants in RGB
my $COLOR = {
    LIGHT_BLUE => SDL::Color->new( 66, 167, 244),
};
my $event    = SDL::Event->new;
my $laser    = 0;
my $velocity = 10;
# ---------------------------------------------------------Events
$app->add_event_handler( \&quit_event);
$app->add_move_handler ( \&calculate_laser);
$app->add_show_handler ( \&render_laser);

$app->run;
# -------------------------------------------------------------Functions:
# quit_event - close the window 
# ---------------------------------------------------------quit_event
sub quit_event {
    my $event = shift;
    my $controller = shift;

    $controller->stop if $event->type == SDL_QUIT;
}
# -----------------------------------------------------calculate_laser
sub calculate_laser {
    # The step is the difference in Time calculated for the next jump
    my ( $step, $app, $t ) = @_;
    $laser += $velocity * $step;
    $laser = 0 if $laser > $app->width; 
}
# ------------------------------------------------------render_laser
sub render_laser {
    my ( $delta, $app ) = @_;
    # the delta ca be used to render blurred frames
    # draw the backgroud first
    $app->draw_rect( [ 0, 0, $app->width, $app->height ], 0);
    # draw the laser
    $app->draw_rect ( [ $laser, $app->height/2, 10, 2], $COLOR->{LIGHT_BLUE});
    
    $app->update();
}
#sub event_loop {
    # first we poll if an event accured...
    #    while( $event->poll) {
        # if there is an event, we check its type
        #   my $type = $event->type;
        # handle window closing
        # exit if $type == SDL_QUIT;
        # }
        #$app->update;
        #}

